code4.py
	python2.7
	使用pwntool跟server溝通
	印出每一個步驟和最後的flag

code5.py
	python2.7
	使用pwntool跟server溝通
	將密文傳入otp1.py(py3)
	印出最後的flag

code6.py
	python2.7
	使用pwntool跟server溝通
	印出最後的flag
	
code7.py
	python2.7
	使用pwntool跟server溝通
	印出最後的flag

code8.py
	python2.7
	使用pwntool跟server溝通
	使用gmpy2做開n次方運算
	印出最後的flag

code9.py
	python2.7
	需要paramwters的檔案
	印出最後的flag
